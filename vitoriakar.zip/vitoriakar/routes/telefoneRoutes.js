const express = require('express');
const router = express.Router();
const telefoneController = require('../controllers/telefoneController');

router.post('/', telefoneController.createTelefone);
router.get('/', telefoneController.readTelefone);
router.put('/:id', telefoneController.updateTelefone);
router.delete('/:id', telefoneController.deleteTelefone);


module.exports = router;