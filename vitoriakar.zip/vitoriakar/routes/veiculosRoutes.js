const express = require('express');
const router = express.Router();
const veiculosController = require('../controllers/veiculosController');

router.post('/', veiculosController.createVeiculos);
router.get('/', veiculosController.readVeiculos);
router.put('/:id', veiculosController.updateVeiculos);
router.delete('/:id', veiculosController.deleteVeiculos);


module.exports = router;