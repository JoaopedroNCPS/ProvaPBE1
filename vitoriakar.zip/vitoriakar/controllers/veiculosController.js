const Veiculos = require('../models/veiculosModel');

const createVeiculos = (req, res) => {
    const {marca_veiculo} = req.body;
    Veiculos.create(marca_veiculo, (err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.status(201).json({message:'Veiculo criado com sucesso', result});

    });
};

const readVeiculos = (req, res) => {
    Veiculos.getAll((err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.json(result);
    });
};

const updateVeiculos = (req, res) => {
    const {marca_veiculo} = req.body;
    Veiculos.update(req.params.id, marca_veiculo, (err,result) => {
        if (err) {
            return res.status(500).json ({error:err.message});
        }
        res.json({message: 'Veiculo atualizado com sucesso', result});
    });
};

const deleteVeiculos = (req, res) => {
    Veiculos.delete(req.params.id, (err, result) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json({message: 'Veiculo removido com sucesso', result});
    });
};

module.exports = {createVeiculos, readVeiculos, updateVeiculos, deleteVeiculos};