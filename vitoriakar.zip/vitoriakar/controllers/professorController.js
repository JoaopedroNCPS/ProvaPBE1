const Professor = require('../models/professorModel');

const createProfessor = (req, res) => {
    const {nome} = req.body;
    Professor.create(nome, (err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.status(201).json({message:'Professor criado com sucesso', result});

    });
};

const readProfessor = (req, res) => {
    Professor.getAll((err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.json(result);
    });
};

const updateProfessor = (req, res) => {
    const {nome} = req.body;
    Professor.update(req.params.id, nome, (err,result) => {
        if (err) {
            return res.status(500).json ({error:err.message});
        }
        res.json({message: 'Professor atualizado com sucesso', result});
    });
};

const deleteProfessor = (req, res) => {
    Professor.delete(req.params.id, (err, result) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json({message: 'Professor removido com sucesso', result});
    });
};

module.exports = {createProfessor, readProfessor, updateProfessor, deleteProfessor};