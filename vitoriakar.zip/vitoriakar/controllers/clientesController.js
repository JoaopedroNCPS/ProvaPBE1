const Clientes = require('../models/clientesModel');

const createClientes = (req, res) => {
    const {nome} = req.body;
    Clientes.create(nome, (err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.status(201).json({message:'Cliente criado com sucesso', result});

    });
};

const readClientes = (req, res) => {
    Clientes.getAll((err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.json(result);
    });
};

const updateClientes = (req, res) => {
    const {nome} = req.body;
    Clientes.update(req.params.id, nome, (err,result) => {
        if (err) {
            return res.status(500).json ({error:err.message});
        }
        res.json({message: 'Cliente atualizado com sucesso', result});
    });
};

const deleteClientes = (req, res) => {
    Clientes.delete(req.params.id, (err, result) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json({message: 'Cliente removido com sucesso', result});
    });
};

module.exports = {createClientes, readClientes, updateClientes, deleteClientes};