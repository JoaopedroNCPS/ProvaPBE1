const Telefone = require('../models/telefoneModel');

const createTelefone = (req, res) => {
    const {numero} = req.body;
    Telefone.create(numero, (err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.status(201).json({message:'Telefone criado com sucesso', result});

    });
};

const readTelefone = (req, res) => {
    Telefone.getAll((err, result) => {
        if (err) {
            return res.status(500).json({error:err.message});
        }
        res.json(result);
    });
};

const updateTelefone = (req, res) => {
    const {numero} = req.body;
    Telefone.update(req.params.id, numero, (err,result) => {
        if (err) {
            return res.status(500).json ({error:err.message});
        }
        res.json({message: 'Telefone atualizado com sucesso', result});
    });
};

const deleteTelefone = (req, res) => {
    Telefone.delete(req.params.id, (err, result) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json({message: 'Telefone removido com sucesso', result});
    });
};

module.exports = {createTelefone, readTelefone, updateTelefone, deleteTelefone};