const db = require ('../database/database');

const Telefone ={
    //Read
    getAll: (callback) => {
        db.query('SELECT * FROM telefone', callback);
    },
    getbyId: (telefone_id, callback) => {
        db.query('SELECT * FROM telefone WHERE telefone_id = ?',[telefone_id], callback);
    },
    // Create
    create: (numero,callback) => {
        db.query('INSERT INTO telefone (numero) VALUES (?)',[numero], callback);
    },
    //Update
    update: (telefone_id, numero, callback) => {
        db.query('UPDATE telefone SET numero = ? WHERE telefone_id = ?', [numero, telefone_id], callback);
    },
    //Delete
    delete: (telefone_id, callback) => {
        db.query('DELETE FROM telefone WHERE telefone_id = ?',[telefone_id], callback);
    }
    
};

module.exports = Telefone;