const db = require ('../database/database');

const Professor ={
    //Read
    getAll: (callback) => {
        db.query('SELECT * FROM professor', callback);
    },
    getbyId: (professor_id, callback) => {
        db.query('SELECT * FROM professor WHERE professor_id = ?',[professor_id], callback);
    },
    // Create
    create: (nome,callback) => {
        db.query('INSERT INTO professor (nome) VALUES (?)',[nome], callback);
    },
    //Update
    update: (professor_id, nome, callback) => {
        db.query('UPDATE professor SET nome = ? WHERE professor_id = ?', [nome, professor_id], callback);
    },
    //Delete
    delete: (professor_id, callback) => {
        db.query('DELETE FROM professor WHERE professor_id = ?',[professor_id], callback);
    }
    
};

module.exports = Professor;