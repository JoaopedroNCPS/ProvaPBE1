const db = require ('../database/database');

const Clientes ={
    //Read
    getAll: (callback) => {
        db.query('SELECT * FROM clientes', callback);
    },
    getbyId: (cliente_id, callback) => {
        db.query('SELECT * FROM clientes WHERE cliente_id = ?',[cliente_id], callback);
    },
    // Create
    create: (nome,callback) => {
        db.query('INSERT INTO clientes (nome) VALUES (?)',[nome], callback);
    },
    //Update
    update: (cliente_id, nome, callback) => {
        db.query('UPDATE clientes SET nome = ? WHERE cliente_id = ?', [nome, cliente_id], callback);
    },
    //Delete
    delete: (cliente_id, callback) => {
        db.query('DELETE FROM clientes WHERE cliente_id = ?',[cliente_id], callback);
    }
    
};

module.exports = Clientes;