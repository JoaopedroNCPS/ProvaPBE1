const db = require ('../database/database');

const Veiculos ={
    //Read
    getAll: (callback) => {
        db.query('SELECT * FROM veiculos', callback);
    },
    getbyId: (veiculos_id, callback) => {
        db.query('SELECT * FROM veiculos WHERE veiculos_id = ?',[veiculos_id], callback);
    },
    // Create
    create: (marca_veiculo,callback) => {
        db.query('INSERT INTO veiculos (marca_veiculo) VALUES (?)',[marca_veiculo], callback);
    },
    //Update
    update: (veiculos_id, marca_veiculo, callback) => {
        db.query('UPDATE veiculos SET marca_veiculo = ? WHERE veiculos_id = ?', [marca_veiculo, veiculos_id], callback);
    },
    //Delete
    delete: (veiculos_id, callback) => {
        db.query('DELETE FROM veiculos WHERE veiculos_id = ?',[veiculos_id], callback);
    }
    
};

module.exports = Veiculos;